#include <iostream>
#define MAX 100
#include <vector>
#include <fstream>
using namespace std;

//Paulo Victor RA: 22117021-0

class  LES{
  private:
    int n;
    int v[MAX];
  public:
    LES() : n(0){

    }
    bool insere(int valor){
      
      if(n == MAX)// n igual a MAX n insere mais
        return false;

      int i;
      for(i = 0;i < n && v[i] < valor;i++); //tem meio q um if dentro desse for

      for(int j = n; j>i ; j--){
        v[j] = v[j - 1];
      }

      v[i] = valor;
      n++;
      return true;
    }
    void imprime() const{
      for(int i = 0;i<n;i++){
        cout << v[i] << " ";
      }
      cout << endl;
    }

    void busca(){
      int valor;
      int i;
      cout<<"Digite o numero que você deseja buscar:"<<endl;
      cin >> valor;
      for(i=0;i<n;i++){
        if(valor == v[i]){
          cout << "Seu numero é: " << v[i] << " Está na posição: " << i << endl;
        }          
      }
    }

    void excluir(){
      int valor2;
      int i;
      
      
      cout<<"Digite o numero que você deseja excluir:"<<endl;
      cin >> valor2;
      int temp;
      for(i=0;i<n;i++){
        if(v[i]==valor2){
          int dif = n-i;
          while(dif!=0){
            v[i] = v[i+1];
            dif--;
            i++;
          }
          n--; 
        }
          
        
      }
                  
    }
    
}; 

ostream& operator<<(ostream& a,const LES& b){
  b.imprime();
  return a;
}

int main() {
  LES v;
  int resp = 2;
  while(resp == 2){
    cout <<"-------------------------------------"<<endl; 
    cout << "Entre com os 5 numeros que voce deseja inserir:" << endl;
    int valor;
    for(int i=0;i<5;i++){
      cin >> valor;
      v.insere(valor);  
    }
    
    cout << "Deseja adicionar mais algum numero? [1] Nao [2] Sim" << endl;
    cin >> resp;
  }
  v.imprime();
  v.busca();
  v.excluir();
  v.imprime();

  ofstream f; //arquivo q vai abrir com os resultados
  f.open("test.txt", ios::out);
  f << v;
  f.close();
}